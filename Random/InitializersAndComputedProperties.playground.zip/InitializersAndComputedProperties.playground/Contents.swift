import UIKit

struct Temperature{
    var celcius: Double
    var fahrenheit: Double
    var kelvin: Double
    
    init(celcius: Double){
        self.celcius = celcius
        fahrenheit = celcius * 1.8 + 32
        kelvin = celcius + 273.15
    }
    
}

let temperatue = Temperature(celcius: 100)
print(temperatue.fahrenheit)

struct StepCounter{
    var totalSteps: Int = 0{
        willSet{
            print("About to set total steps to \(newValue)")
        }
        didSet{
            if totalSteps > oldValue{
                print("Added \(totalSteps - oldValue) steps")
            }
        }
    }
}

var stepCounter = StepCounter()
stepCounter.totalSteps = 40
stepCounter.totalSteps = 100

