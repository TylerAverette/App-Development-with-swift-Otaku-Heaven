import UIKit

struct Note: Codable{
    let title: String
    let text: String
    let timeStamp: Date
}


//*********Part I *************

//let newNote = Note(title: "Grocery run", text: "Pick up mayonnaise, lettuce, tomato, and pickles.", timeStamp: Date())

//// Try? is a throwing function that will return nil upon failure
//let propertyListEncoder = PropertyListEncoder()
//if let encodedNote = try? propertyListEncoder.encode(newNote){
//    print(encodedNote)
//
//    let propertyListDecoder = PropertyListDecoder()
//    if let decodedNote = try? propertyListDecoder.decode(Note.self, from: encodedNote){
//        print(decodedNote)
//    }
//}

// ************** Part II ***************

let newNote = Note(title: "Grocery run", text: "Pick up mayonnaise, lettuce, tomato, and pickles.", timeStamp: Date())
let note1 = Note(title: "Note One", text: "This is a sample note.", timeStamp: Date())
let note2 = Note(title: "Note Two", text: "This is another sample note.", timeStamp: Date())
let note3 = Note(title: "Note Three", text: "This is yet another sample note.", timeStamp: Date())
let notes = [note1, note2, note3]

// userDomainMask refers to the users home folder, documentDirectory is the search parameter
// This will give you the folder that you can read or write data to
let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
// This targets the file in the directory
let archiveURL = documentsDirectory.appendingPathComponent("notes_test").appendingPathExtension("plist")

let propertyListEncoder = PropertyListEncoder()
let encodedNote = try? propertyListEncoder.encode(newNote)

// write data to the file
try? encodedNote?.write(to: archiveURL, options: .noFileProtection)

// retrieve our Data
let propertyListDecoder = PropertyListDecoder()
if let retrievedNoteData = try? Data(contentsOf: archiveURL),
    let decodedNote = try? propertyListDecoder.decode(Note.self, from: retrievedNoteData){
        print(decodedNote)
}

print("\(notes[0])")
print("\(notes[1])")
print("\(notes[2])")
